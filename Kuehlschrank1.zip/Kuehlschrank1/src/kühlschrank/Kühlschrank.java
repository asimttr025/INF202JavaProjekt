/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package kühlschrank;
import Design.multipanel;
import Design.*;

/**
 *
 * @author Ertas
 */
public class Kühlschrank{

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        multipanel ekran=new multipanel();
        ekran.setVisible(true);
    }
    
}

