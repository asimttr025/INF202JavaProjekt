
import java.io.IOException;
import java.net.URL;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.ResourceBundle;
import java.util.logging.Level;
import java.util.logging.Logger;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.ComboBox;
import javafx.scene.control.Label;
import javafx.scene.control.PasswordField;
import javafx.scene.control.ProgressBar;
import javafx.scene.control.TextField;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.AnchorPane;
import javafx.scene.paint.Color;
import javafx.stage.Stage;
import utils.ConnectionUtil;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableRow;
import javafx.scene.control.TableView;

public class sceneController implements Initializable {

    private Stage stage;
    private Scene scene;
    private Parent root;

    ObservableList<Integer> slots = FXCollections.observableArrayList();
    ObservableList<Benutzer> benutzerList = FXCollections.observableArrayList();
    ObservableList<String> schrankListe = FXCollections.observableArrayList("Schrank1", "Schrank2", "Schrank3");
    ObservableList<Gerate> gerateListe = FXCollections.observableArrayList();
    //combobox icerigi olusturmak icin kullanildi
    ObservableList<String> slotNumbers = FXCollections.observableArrayList(Arrays.asList("1", "2", "3", "4", "5", "6", "7", "8", "9", "10", "11", "12", "13", "14", "15", "16", "17", "18", "19", "20"));
    Connection con = null;
    PreparedStatement preparedStatement = null;
    ResultSet resultSet = null;

    @FXML
    private Button fertig_button, funktest_button, abbrechen_button, kontroll_button, sorunvar, sorunyok, geciciweiter_button,
            haupttest_start_button, pauseTest_button, abbrechenTest_button, weiterTest_button, testInOrdnung_button,
            testNichtInOrdnung_button, testInOrdnung2_button, ende_button, login_button, confirm_button;
    @FXML
    private AnchorPane loginPane, schrankPane, menuAdminPane, menuBenutzerPane, initialisierungStartPane, initialisierungPane, benutzerSettings, benutzerSettingsPane,
            settingsPane, schrankSettingsPane,
            weiterZumTestProduktCheckInPane, testProduktCheckInPane, produkt_pane1, vortestPane, haupttestPane, haupttestEndePane, funktionCheckPane, funktionCheckPane2, endePane,
            testProduktCheckInStartPane, anchorHaupttest, produkt_pane, erfolgreich_pane1, fertig_pane1, funktest_pane1, pruef_pane, fehler_pane, bevorNachtest_pane, nachtest_pane, bevorHaupttest_pane;
    @FXML
    private Label testInOrdnung_text, testNichtInOrdnung_text, lblErrors, lblStatus1, lblStatus, lblStatusSchrank, lblStatusSchrank1, hinzufuegen_label, entfernen_label;
    @FXML
    private TextField txtId, schrankid_txtfield1, schrankid_txtfield, benutzerid_txtfield, benutzerPassword_txtfield, benutzerName_txtfield,
            benutzerNachame_txtfield, benutzerid_txtfield1, schrank_benutzerid, benutzerRolle_txtfield, bauteil_textfield, auftrag_textfield;
    @FXML
    private PasswordField txtPassword;
    @FXML
    private ComboBox<String> schrankBox, slot_combobox1, entfernen_combobox;
    @FXML
    private ProgressBar progress_bar;
    //deneme amacli devre disi birakip sadece TableColumn versiyonunu test ettiydim bir sorun cikmadi
    @FXML
    private TableColumn<Gerate, Integer> bauteil_column, slot_column;
    @FXML
    private TableColumn<Gerate, String> auftrag_column, ergebnis_column;
    @FXML
    private TableView burnintest_table, burnintest_table1, burnintest_table2, burnintest_table3, burnintest_table4;
    //@FXML
    //private TableColumn slot_column, bauteil_column, auftrag_column, ergebnis_column;

    public sceneController() {
        con = ConnectionUtil.conDB();
    }

    @Override
    public void initialize(URL url, ResourceBundle rb) {
        schrankBox.setValue("Schrank1");
        schrankBox.setItems(schrankListe);
        slot_combobox1.setValue("1");
        slot_combobox1.setItems(slotNumbers);
        loadBenutzerList();
        //screen degistiginde "online" attributeu tekrar false yukleniyor 130.satir duzelmeli
    }

    //artik tum scene ler tek bir fxml de sirayla setVisible yaparak inceleyebilirsiniz
    //switchScreen(event, eski_sayfa, yeni_sayfa, yeni_sayfanin_adi) 
    public void switchScreen(ActionEvent event, AnchorPane oldPaneId, AnchorPane newPaneId, String title) {
        oldPaneId.setVisible(false);
        newPaneId.setVisible(true);
        stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
        stage.setTitle(title);
    }

    public void loadBenutzerList() {
        try {
            String st = "SELECT * FROM `benutzer`";
            preparedStatement = (PreparedStatement) con.prepareStatement(st);
            resultSet = preparedStatement.executeQuery();
            while (resultSet.next()) {
                benutzerList.add(new Benutzer(
                        resultSet.getInt("benutzer_id"),
                        resultSet.getString("password"),
                        resultSet.getString("name"),
                        resultSet.getString("nachname"),
                        resultSet.getString("rolle"),
                        resultSet.getBoolean("Online")));
            }
        } catch (SQLException ex) {
            System.out.println(ex.getMessage());
        }
    }

    //we gonna use string to check for status
    private String logIn() {
        String status = "Success";
        String benutzer_id = txtId.getText();
        String password = txtPassword.getText();
        if (benutzer_id.isEmpty() || password.isEmpty()) {
            setLblError(Color.TOMATO, "Empty credentials");
            status = "Error";
        } else {
            //query
            String sql = "SELECT * FROM benutzer Where benutzer_id = ? and password = ?";
            try {
                preparedStatement = con.prepareStatement(sql);
                preparedStatement.setString(1, benutzer_id);
                preparedStatement.setString(2, password);
                resultSet = preparedStatement.executeQuery();
                if (!resultSet.next()) {
                    setLblError(Color.TOMATO, "Enter Correct Id/Password");
                    status = "Error";
                } else {
                    setLblError(Color.GREEN, "Login Successful..Redirecting..");
                }
            } catch (SQLException ex) {
                System.err.println(ex.getMessage());
                status = "Exception";
            }
        }
        benutzerDataSetOnline(benutzer_id);
        return status;
    }

    public void benutzerDataSetOnline(String benutzer_id) {
        for (Benutzer b : benutzerList) {
            if (b.getId() == Integer.parseInt(benutzer_id)) {
                b.setOnline(true);
                String sql = "UPDATE benutzer SET Online='" + 1 + "' WHERE benutzer_id='" + b.getId() + "' ";
                try {
                    preparedStatement = con.prepareStatement(sql);
                    preparedStatement.execute();
                } catch (SQLException ex) {
                    System.err.println(ex.getMessage());
                }
            }
        }
    }

    public void benutzerDataSetOffline() {
        for (Benutzer b : benutzerList) {
            if (b.isOnline()) {
                b.setOnline(false);
                String sql = "UPDATE benutzer SET Online='" + 0 + "' WHERE benutzer_id='" + b.getId() + "' ";
                try {
                    preparedStatement = con.prepareStatement(sql);
                    preparedStatement.execute();
                } catch (SQLException ex) {
                    System.err.println(ex.getMessage());
                }
            }
        }
    }

    private void setLblError(Color color, String text) {
        lblErrors.setTextFill(color);
        lblErrors.setText(text);
        System.out.println(text);
    }

    private void clear_Fields() {
        benutzerid_txtfield1.clear();
    }

    private String entfernenBenutzerData() {
        try {
            String st = "DELETE FROM benutzer where benutzer_id=?";
            preparedStatement = (PreparedStatement) con.prepareStatement(st);
            preparedStatement.setString(1, benutzerid_txtfield1.getText());
            preparedStatement.executeUpdate();
            lblStatus1.setTextFill(Color.GREEN);
            lblStatus1.setText("Benutzer erfolgreich entfernen");
            clear_Fields();
            return "Success";

        } catch (SQLException ex) {
            System.out.println(ex.getMessage());
            lblStatus1.setTextFill(Color.TOMATO);
            lblStatus1.setText(ex.getMessage());
            return "Exception";
        }

    }

    private void clearFields() {
        benutzerid_txtfield.clear();
        benutzerPassword_txtfield.clear();
        benutzerName_txtfield.clear();
        benutzerNachame_txtfield.clear();
        benutzerRolle_txtfield.clear();
    }

    private String hinzufuegenBenutzerData() {

        try {
            String st = "INSERT INTO benutzer (benutzer_id, password, name, nachname, rolle) VALUES (?,?,?,?,?)";
            preparedStatement = (PreparedStatement) con.prepareStatement(st);
            preparedStatement.setString(1, benutzerid_txtfield.getText());
            preparedStatement.setString(2, benutzerPassword_txtfield.getText());
            preparedStatement.setString(3, benutzerName_txtfield.getText());
            preparedStatement.setString(4, benutzerNachame_txtfield.getText());
            preparedStatement.setString(5, benutzerRolle_txtfield.getText());
            preparedStatement.executeUpdate();
            lblStatus.setTextFill(Color.GREEN);
            lblStatus.setText("Benutzer erfolgreich hinzugefügt");
            clearFields();
            return "Success";

        } catch (SQLException ex) {
            System.out.println(ex.getMessage());
            lblStatus.setTextFill(Color.TOMATO);
            lblStatus.setText(ex.getMessage());
            return "Exception";
        }
    }

    private void clearSchrank_Fields() {
        schrankid_txtfield.clear();
    }

    private String entfernenSchrankData() {
        try {
            String st = "DELETE FROM klimaschrank where klimaschrank_id=?";
            preparedStatement = (PreparedStatement) con.prepareStatement(st);
            preparedStatement.setString(1, schrankid_txtfield.getText());
            preparedStatement.executeUpdate();
            lblStatusSchrank.setTextFill(Color.GREEN);
            lblStatusSchrank.setText("Schrank erfolgreich entfernen");
            clearSchrank_Fields();
            return "Success";

        } catch (SQLException ex) {
            System.out.println(ex.getMessage());
            lblStatusSchrank.setTextFill(Color.TOMATO);
            lblStatusSchrank.setText(ex.getMessage());
            return "Exception";
        }

    }

    private String hinzufuegenSchrankData() {

        try {
            String st = "INSERT INTO klimaschrank (klimaschrank_id,benutzer_id) VALUES (?,?)";
            preparedStatement = (PreparedStatement) con.prepareStatement(st);
            preparedStatement.setString(1, schrankid_txtfield1.getText());
            preparedStatement.setString(2, schrank_benutzerid.getText());
            preparedStatement.executeUpdate();
            lblStatusSchrank1.setTextFill(Color.GREEN);
            lblStatusSchrank1.setText("Schrank erfolgreich hinzugefügt");
            clearSchrank1_Fields();
            return "Success";

        } catch (SQLException ex) {
            System.out.println(ex.getMessage());
            lblStatusSchrank1.setTextFill(Color.TOMATO);
            lblStatusSchrank1.setText(ex.getMessage());
            return "Exception";
        }
    }

    private void clearSchrank1_Fields() {
        schrankid_txtfield1.clear();
        schrank_benutzerid.clear();
    }

    private void hinzufuegenGerateData(Gerate g) {

        Benutzer benutzer = new Benutzer();
        for (Benutzer b : benutzerList) {
            if (b.isOnline()) {
                benutzer = b;
            }
        }

        try {
            String st = "INSERT INTO gerate (gerate_id, gerate_name, start_temperatur, ziel_temperatur, auftrag, slot_id, benutzer_id, vortest_ergebnis, haupttest_ergebnis) VALUES (?,?,?,?,?,?,?,?,?)";
            preparedStatement = (PreparedStatement) con.prepareStatement(st);
            preparedStatement.setInt(1, g.getBauteil());
            preparedStatement.setString(2, g.getName());
            preparedStatement.setInt(3, g.getStart_temperatur());
            preparedStatement.setInt(4, g.getZiel_temperatur());
            preparedStatement.setString(5, g.getAuftrag());
            preparedStatement.setInt(6, g.getSlot_id());
            preparedStatement.setInt(7, benutzer.getId());
            preparedStatement.setString(8, g.getVortest_ergebnis());
            preparedStatement.setString(9, g.getHaupttest_ergebnis());
            //TODO databasede benutzer icin online attribute kaydedildiginde ustteki satir yerine alttaki calisacak
            //preparedStatement.setInt(7, benutzer.getId());
            preparedStatement.executeUpdate();
            hinzufuegen_label.setTextFill(Color.GREEN);
            hinzufuegen_label.setText("Geraet erfolgreich hinzugefügt");

            burnintest_table.getItems().add(g);

            bauteil_textfield.clear();
            auftrag_textfield.clear();

        } catch (SQLException ex) {
            System.out.println(ex.getMessage());
        }
    }
    //urun eklerken bauteil_id primary key olarak dusunuldu yani
    //ayni urunu 2. kez DB ye yuklemesine izin vermeyecek ve
    //ayni slota 2. bir urun yerlestirilemeyecek 
    //slotlar farkli sirada doldurulabiliyor ama tablodan kucuk<buyuk veya
    //tersine siralama ozelligine sahip
    List<Gerate> attachedDevices = new ArrayList<>();
    List<Integer> usedSlots = new ArrayList<>();

    @FXML
    void hinzufuegen_buttonClicked(ActionEvent event) {
        slot_column.setCellValueFactory(new PropertyValueFactory<>("slot_id"));
        bauteil_column.setCellValueFactory(new PropertyValueFactory<>("bauteil"));
        auftrag_column.setCellValueFactory(new PropertyValueFactory<>("auftrag"));
        ergebnis_column.setCellValueFactory(new PropertyValueFactory<>("ergebnis"));
        if (bauteil_textfield.getText().isEmpty() || auftrag_textfield.getText().isEmpty()) {
            hinzufuegen_label.setTextFill(Color.TOMATO);
            hinzufuegen_label.setText("Geben Sie alle Details ein");
        } else {
            hinzufuegen_label.setText("");
            //Gerate gerate = new Gerate();
            //TODO combobox duzelince alttaki satir caliscak
            int slotNumber = Integer.parseInt(slot_combobox1.getSelectionModel().getSelectedItem());
            //gerate.setSlot_id(slotNumber);
            //gerate.setBauteil(Integer.parseInt(bauteil_textfield.getText()));
            //gerate.setAuftrag(auftrag_textfield.getText());
            int bauteilId = Integer.parseInt(bauteil_textfield.getText());
            String auftrag = auftrag_textfield.getText();
            Gerate gerate = new Gerate(slotNumber, bauteilId, auftrag, "Kein ergebnis");
            String sql = "SELECT gerate_id FROM gerate Where gerate_id = ?";
            boolean unique_gerateID = false;
            //urun eklerken DB kontrolu yapiyor onceden yuklenmis mi diye eger DB de yok ise ve mevcut slot bos ise kayit islemi
            //gerceklesiyor
            try {
                preparedStatement = con.prepareStatement(sql);
                preparedStatement.setString(1, bauteil_textfield.getText());
                resultSet = preparedStatement.executeQuery();
                if (!resultSet.next()) {
                    unique_gerateID = true;
                }
            } catch (SQLException ex) {
                System.err.println(ex.getMessage());
            }
            if (!usedSlots.contains(slotNumber) && unique_gerateID) {
                attachedDevices.add(gerate);
                usedSlots.add(slotNumber);
                hinzufuegenGerateData(gerate);
            } else {
                if (!unique_gerateID) {
                    hinzufuegen_label.setTextFill(Color.TOMATO);
                    hinzufuegen_label.setText("Geraet-ID existiert. Kontrollieren Sie bitte das Geraet-Id.");
                } else {
                    hinzufuegen_label.setTextFill(Color.TOMATO);
                    hinzufuegen_label.setText("Slot " + slotNumber + " ist besetzt waehlen Sie bitte ein anderes Slot.");
                }
            }

        }
    }

    //urun kaldirma seklini degistirmek zorunda kaldim comboboxtan tablo satirini secmeyi yapamadim
    //onun yerine tablodan urun satirina tiklayip sil butonuna basiyoruz ve urun tablodan ve DB den siliniyor
    @FXML
    void entfernen_gerateData(ActionEvent event) {
        int selectedIndex = burnintest_table.getSelectionModel().getSelectedIndex();
        if (selectedIndex >= 0) {
            Gerate a = (Gerate) burnintest_table.getSelectionModel().getSelectedItem();
            int slot_id = a.getSlot_bauteil_id()[0];
            int bauteil_id = a.getSlot_bauteil_id()[1];
            entfernen_label.setText("Slot " + slot_id + " ist aus der Tabelle entfernt.");
            burnintest_table.getItems().remove(selectedIndex);
            for (int i = 0; i <= usedSlots.size() - 1; i++) {
                if (usedSlots.get(i) == slot_id) {
                    int x = usedSlots.remove(i);
                    System.out.println("Removed slot =" + x);
                }
            }
            for (int i = 0; i < attachedDevices.size() - 1; i++) {
                if (attachedDevices.get(i).getBauteil() == bauteil_id) {
                    attachedDevices.remove(i);
                }
            }
            try {
                String sql = "DELETE FROM gerate Where gerate_id=?";
                preparedStatement = con.prepareStatement(sql);
                preparedStatement.setInt(1, a.getBauteil());
                preparedStatement.executeUpdate();
                System.out.println("Gerat ist aus DB gelöscht");
            } catch (SQLException ex) {
                System.err.println(ex.getMessage());
            }
        } else {
            entfernen_label.setText("Kein Slot ausgewählt.");
        }
    }

    @FXML
    void benutzerhinzufuegen_buttonClicked(ActionEvent event) {
        if (benutzerid_txtfield.getText().isEmpty() || benutzerPassword_txtfield.getText().isEmpty() || benutzerName_txtfield.getText().isEmpty() || benutzerNachame_txtfield.getText().isEmpty()) {
            lblStatus.setTextFill(Color.TOMATO);
            lblStatus.setText("Geben Sie alle Details ein");
        } else {
            hinzufuegenBenutzerData();
        }
    }

    @FXML
    void benutzerentfernen_buttonClicked(ActionEvent event) {
        if (benutzerid_txtfield1.getText().isEmpty()) {
            lblStatus1.setTextFill(Color.TOMATO);
            lblStatus1.setText("Geben Sie alle Details ein");
        } else {
            entfernenBenutzerData();
        }
    }

    @FXML
    void benutzerstellung_is_Clicked(ActionEvent event) {
        switchScreen(event, settingsPane, benutzerSettingsPane, "Benutzer-Einstellungen");
    }

    @FXML
    void schrankstellung_is_Clicked(ActionEvent event) {
        switchScreen(event, settingsPane, schrankSettingsPane, "Schrank-Einstellungen");
    }

    @FXML
    void schrankentfernen_buttonClicked(ActionEvent event) {
        if (schrankid_txtfield.getText().isEmpty()) {
            lblStatusSchrank.setTextFill(Color.TOMATO);
            lblStatusSchrank.setText("Geben Sie alle Details ein");
        } else {
            entfernenSchrankData();
        }
    }

    @FXML
    void schrankhinzufuegen_buttonClicked(ActionEvent event) {
        if (schrankid_txtfield1.getText().isEmpty() || schrank_benutzerid.getText().isEmpty()) {
            lblStatusSchrank1.setTextFill(Color.TOMATO);
            lblStatusSchrank1.setText("Geben Sie alle Details ein");
        } else {
            hinzufuegenSchrankData();
        }
    }

    @FXML
    void menuzuruckgehen_isClicked(ActionEvent event) {
        switchScreen(event, benutzerSettingsPane, menuAdminPane, "Einstellungen");
        switchScreen(event, schrankSettingsPane, menuAdminPane, "Einstellungen");
    }

    //Einstellungen ausgewählt
    @FXML
    void settings_button_isClicked(ActionEvent event) {
        switchScreen(event, menuAdminPane, settingsPane, "Einstellungen");
    }

    @FXML
    void login_button_isClicked(ActionEvent event) {
        if (logIn().equals("Success")) {
            switchScreen(event, loginPane, schrankPane, "Schrankauswahl");
        }
    }

    //Schrankauswahl
    @FXML
    void confirm_button_isClicked(ActionEvent event) {
        //if
        switchScreen(event, schrankPane, menuAdminPane, "Menu");
        //else
        //switchScreen(event, schrankPane, menuBenutzerPane, "Menu");
    }

    //Testbetrieb ausgewählt
    @FXML
    void testbetrieb_button_isClicked(ActionEvent event) {
        switchScreen(event, menuAdminPane, initialisierungStartPane, "Initialisierung Starten");
    }

    //Handbetrieb ausgewählt
    @FXML
    void handbetrieb_button_isClicked(ActionEvent event) {

    }

    //Programm beenden
    @FXML
    void exit_button_isClicked(ActionEvent event) {
        System.exit(0);
    }

    //Abbrechen führt immer zurück zum Hauptmenü
    @FXML
    void abbrechen_button_isClicked(ActionEvent event) {
        //geri butonunu iptal ettim nasıl olacağına toplu karar veririz
        //düzenleme gerekli
    }

    //Initialisierung starten
    @FXML
    void initialisierungStart_button_isClicked(ActionEvent event) {
        switchScreen(event, initialisierungStartPane, initialisierungPane, "Initialisierung");
    }

    //Weiter button zum Testprodukt Check-In Starten
    @FXML
    void weiterZumTestProduktCheckIn_button_isClicked(ActionEvent event) {
        switchScreen(event, initialisierungPane, weiterZumTestProduktCheckInPane, "Testprodukt Check-In Starten");
    }

    //Testprodukt Check-In Starten
    @FXML
    void testProduktCheckStart_button_isClicked(ActionEvent event) {
        switchScreen(event, weiterZumTestProduktCheckInPane, testProduktCheckInPane, "Testprodukt Check-In");
    }

    @FXML
    public void fertig_button_isClicked(ActionEvent event) {
        usedSlots.clear();
        produkt_pane1.setVisible(false);
        erfolgreich_pane1.setVisible(true);
        fertig_pane1.setVisible(false);
        funktest_pane1.setVisible(true);
        hinzufuegen_label.setText("");
    }

    @FXML
    public void funktest_button_isClicked(ActionEvent event) {
        switchScreen(event, testProduktCheckInPane, vortestPane, "Vortest");
        produkt_pane1.setVisible(true);
        erfolgreich_pane1.setVisible(false);
        fertig_pane1.setVisible(true);
        funktest_pane1.setVisible(false);
        slot_combobox1.setValue("1");

    }

    //TODO "sorunvar" "sorunyok" butonlari silinecek testin sonucuna gore ekranlar otomatik acilacak
    @FXML
    public void sorunvar_isClicked(ActionEvent event) {
        pruef_pane.setVisible(false);
        fehler_pane.setVisible(true);
        abbrechen_button.setVisible(true);
        sorunvar.setVisible(false);
        sorunyok.setVisible(false);
        nachtest_pane.setVisible(false);
    }

    @FXML
    public void sorunyok_isClicked(ActionEvent event) {
        pruef_pane.setVisible(false);
        bevorHaupttest_pane.setVisible(true);
        abbrechen_button.setVisible(true);
        sorunvar.setVisible(false);
        sorunyok.setVisible(false);

        nachtest_pane.setVisible(false);
    }

    @FXML
    public void kontroll_button_isClicked(ActionEvent event) {
        //TODO eger hatali urunler uzaklastirilmadiysa burda kalacak
        //eger uzaklastirildilarsa:
        fehler_pane.setVisible(false);
        bevorNachtest_pane.setVisible(true);
    }

    @FXML
    public void nachtest_button_isClicked(ActionEvent event) {
        bevorNachtest_pane.setVisible(false);
        nachtest_pane.setVisible(true);
        abbrechen_button.setVisible(false);
        //TODO "sorunvar" "sorunyok" butonlari silinecek testin sonucuna gore ekranlar otomatik acilacak
        sorunvar.setVisible(true);
        sorunyok.setVisible(true);
    }

    @FXML
    public void haupttestStartButton_isClicked(ActionEvent event) {
        switchScreen(event, vortestPane, haupttestPane, "Haupttest");
    }

    @FXML
    public void geciciWeiterButton_isClicked(ActionEvent event) {
        switchScreen(event, haupttestPane, haupttestEndePane, "Haupttest fertig");
    }

    @FXML
    public void abbrechenTest_isClicked(ActionEvent event) {

    }

    @FXML
    public void pauseTest_isClicked(ActionEvent event) {

    }

    @FXML
    void weiterTest_isClicked(ActionEvent event) {
        switchScreen(event, haupttestEndePane, funktionCheckPane, "Funktions Check Scene");
    }

    @FXML
    void testInOrdnung_isClicked(ActionEvent event) {
        testInOrdnung_text.setVisible(false);
        testInOrdnung_button.setVisible(false);
        testNichtInOrdnung_text.setVisible(true);
        testNichtInOrdnung_button.setVisible(true);

    }

    @FXML
    void testNichtInOrdnung_isClicked(ActionEvent event) {
        switchScreen(event, funktionCheckPane, funktionCheckPane2, "Funktions Ordnung Scene");
    }

    @FXML
    void testInOrdnung2_isClicked(ActionEvent event) {
        switchScreen(event, funktionCheckPane2, endePane, "Funktions Ordnung Scene");
    }

    @FXML
    void endeClicked(ActionEvent event) {
        //if
        switchScreen(event, endePane, menuAdminPane, "Returning Main Menu");
        //else
        //switchScreen(event,funktionCheckEndePane,menuBenutzerPane, "Returning Main Menu");
        burnintest_table.getItems().clear();
        attachedDevices.clear();
    }

}
