
public class Gerate {

    private int bauteil = -1;
    private String name = "";
    private int start_temperatur = 0;
    private int ziel_temperatur = 0;
    private int slot_id = 1;
    private int benutzer_id = 15;
    private String auftrag = "";
    //önceden eklediğim ergebnis degiskeni vortest ile degistirilebilir
    private String ergebnis = "Kein ergebnis";
    private String vortest_ergebnis = "";
    private String haupttest_ergebnis = "";

    //urun ekleme cikarma yaparken urunleri listeye kaydetmek veya listeden cikarmak icin olusturuldu
    public Gerate(int slot_id, int bauteil, String auftrag, String ergebnis) {
        this.slot_id = slot_id;
        this.bauteil = bauteil;
        this.auftrag = auftrag;
        this.ergebnis = ergebnis;
    }

    @Override
    public String toString() {
        return slot_id + " " + bauteil + " " + auftrag + " " + ergebnis;
    }

    public String getVortest_ergebnis() {
        return vortest_ergebnis;
    }

    public void setVortest_ergebnis(String vortest_ergebnis) {
        this.vortest_ergebnis = vortest_ergebnis;
    }

    public String getHaupttest_ergebnis() {
        return haupttest_ergebnis;
    }

    public void setHaupttest_ergebnis(String nachtest_ergebnis) {
        this.haupttest_ergebnis = nachtest_ergebnis;
    }

    //urunleri silerken slot_id ve bauteil kontrolu yaparak siliyor boylelikle ayni urun veri tabanına iki kere kaydedilmemis oluyor
    //veya ayi slota baska urun eklenemiyor mevcut slot silinmedigi surece
    public int[] getSlot_bauteil_id() {
        int[] array = new int[]{slot_id, bauteil};
        return array;
    }

    public String getErgebnis() {
        return ergebnis;
    }

    public void setErgebnis(String ergebnis) {
        this.ergebnis = ergebnis;
    }

    public int getBauteil() {
        return bauteil;
    }

    public void setBauteil(int bauteil) {
        this.bauteil = bauteil;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public int getStart_temperatur() {
        return start_temperatur;
    }

    public void setStart_temperatur(int start_temperatur) {
        this.start_temperatur = start_temperatur;
    }

    public int getZiel_temperatur() {
        return ziel_temperatur;
    }

    public void setZiel_temperatur(int ziel_temperatur) {
        this.ziel_temperatur = ziel_temperatur;
    }

    public int getSlot_id() {
        return slot_id;
    }

    public void setSlot_id(int slot_id) {
        this.slot_id = slot_id;
    }

    public int getBenutzer_id() {
        return benutzer_id;
    }

    public void setBenutzer_id(int benutzer_id) {
        this.benutzer_id = benutzer_id;
    }

    public String getAuftrag() {
        return auftrag;
    }

    public void setAuftrag(String auftrag) {
        this.auftrag = auftrag;
    }

}
