
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintStream;
import java.net.Socket;
import java.rmi.UnknownHostException;
import java.util.Vector;
import java.util.concurrent.TimeUnit;

public class CabinKontrol {
	
	
	public static void main(String[] args) {
		Socket socket = null;
		try {
			if (args.length == 0) {
				System.out.println("Usage: CabinKontrol <port>");
				System.exit(0);
			}
			
			int port = Integer.parseInt(args[0]);
			socket = new Socket("localhost", port);
			
			
			
			PrintStream ps = new PrintStream(socket.getOutputStream(),true);
			while (true) {
				communique(socket, ps);
			}
		}  catch (UnknownHostException e) {
			System.out.println("Unknown Host..");
			e.printStackTrace();
		} catch (IOException e) {
			System.err.println("IO-Problems:...");
			
		} finally {
			if (socket != null)
				try {
					socket.close();
					System.out.println("Socket closed.. Exiting");
				} catch (IOException e) {
					System.out.println("Socket kapat�lamad�.. exiting");
				}
		}
		
	}

	private static void communique(Socket socket, PrintStream toServer) throws IOException {
		Vector<String> messages = new Vector<String>();
		
		//String string = sceneController.alpi;
		String string1 = sceneController.alpi;
		//System.out.println(string);
		messages.add("STRT|KabinKontrol|"+string1+"|Admin|10|1000"); //Cabinet name| user name| user role| hata y�zdesi
		
		
		messages.add("INIT|3|154875678"); // slotNo | Examinee ID slotnummbers 1..20		
		messages.add("INIT|2|165165");
		messages.add("INIT|4|4564");
		messages.add("INIT|5|4356453");
		messages.add("INIT|7|165113265");
		messages.add("INIT|9|53645");
		messages.add("INIT|10|786535");
		messages.add("INIT|11|6546535");
		messages.add("INIT|14|45686");
		messages.add("INIT|15|35213");
		messages.add("INIT|16|35213");
		messages.add("INIT|18|21354");
		messages.add("INIT|19|56465");
		messages.add("INIT|20|6876");
		
		messages.add("ENDINIT");
		messages.add("STRTPRE|5");
		
		for (int i = 1; i <= 20; i++) {
			messages.add("PRETST|" + i);
			//messages.add("PRETST|" + i);			
			//messages.add("PRETST|" + i);
		}
		messages.add("ENDPRE");
		//messages.add("STOP");
		messages.add("STRTBURNIN");
		//messages.add("BURNIN");
		messages.add("SETTARGET|70.5|180|3|5"); //Target Temperature | TimeFrame[secs] | ToleranceRate[%]
		messages.add("OPERTEMP");
		messages.add("STRTPING|11");
		
		for (int i = 1; i <= 20; i++) {
			messages.add("PING|" + i);
		}
		
		messages.add("STOP");
		
		messages.add("SETTARGET|-30|210|3|5");
		messages.add("OPERTEMP");
		messages.add("STRTPING|11");
		
		for (int i = 1; i <= 20; i++) {
			messages.add("PING|" + i);
		}
		
		messages.add("STOPPING");
		
		BufferedReader fromServer = new BufferedReader(new InputStreamReader(socket.getInputStream()));
		
		for (String message :messages) {
			if (message.startsWith("PRETEST")) {
				String slt = message.substring(8);
				toServer.println(message);
				long start = System.currentTimeMillis();
				fromServer.readLine();
				long stop = System.currentTimeMillis();
				System.out.println("Slot - " + slt + " answered in " + (stop-start) + " milliseconds");			
			}
			else {
				toServer.println(message);
				String answer = fromServer.readLine();
				System.out.println(answer);
				if (answer != null && answer.startsWith("STOPPING")) {
					System.exit(0);					
				}
			}
		}

	}
	
}

