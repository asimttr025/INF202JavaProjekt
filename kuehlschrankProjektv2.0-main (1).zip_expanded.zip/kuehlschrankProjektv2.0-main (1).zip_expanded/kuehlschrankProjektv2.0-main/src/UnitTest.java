import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

class UnitTest {
	sceneController testInstance = new sceneController();
	
	@Test
	void test() {
		String actual = testInstance.logIn();
		assertEquals(actual, "Success");
		System.out.println(actual);
	
	}

}