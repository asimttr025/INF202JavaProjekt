
import java.net.URL;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Collections;
import java.util.Random;
import java.util.ResourceBundle;
import java.util.Timer;
import java.util.TimerTask;
import java.util.concurrent.Semaphore;
import java.util.logging.Level;
import java.util.logging.Logger;
import javafx.application.Platform;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.ComboBox;
import javafx.scene.control.Label;
import javafx.scene.control.PasswordField;
import javafx.scene.control.ProgressBar;
import javafx.scene.control.TextField;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.layout.AnchorPane;
import javafx.scene.paint.Color;
import javafx.stage.Stage;
import utils.ConnectionUtil;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;

public class sceneController implements Initializable {

    private Stage stage;
    private Scene scene;
    private Parent root;

    ObservableList<String> schranken = FXCollections.observableArrayList();
    ObservableList<String> slots = FXCollections.observableArrayList();
    ObservableList<Benutzer> benutzerList = FXCollections.observableArrayList();
    ObservableList<Gerate> gerateList = FXCollections.observableArrayList();
    ObservableList<Gerate> tempGerateList = FXCollections.observableArrayList();
    ObservableList<Gerate> fehlerhafteGerateList = FXCollections.observableArrayList();
    ObservableList<Gerate> korrektGerateList = FXCollections.observableArrayList();

    Connection con = null;
    PreparedStatement preparedStatement = null;
    ResultSet resultSet = null;
    private Semaphore sem = new Semaphore(20);

    @FXML
    private Button fertig_button, funktest_button, abbrechen_button, kontroll_button, sorunvar, sorunyok, geciciweiter_button,
            haupttest_start_button, pauseTest_button, abbrechenTest_button, weiterTest_button, testInOrdnung_button,
            testNichtInOrdnung_button, testInOrdnung2_button, ende_button, login_button, confirm_button, init_weiter_Button;
    @FXML
    private AnchorPane loginPane, schrankPane, menuAdminPane, menuBenutzerPane, initialisierungStartPane, initialisierungPane, benutzerSettings, benutzerSettingsPane,
            settingsPane, schrankSettingsPane,
            weiterZumTestProduktCheckInPane, testProduktCheckInPane, produkt_pane1, vortestPane, haupttestPane, haupttestEndePane, funktionCheckPane, funktionCheckPane2, endePane,
            testProduktCheckInStartPane, anchorHaupttest, produkt_pane, erfolgreich_pane1, fertig_pane1, funktest_pane1, pruef_pane, fehler_pane, bevorNachtest_pane, nachtest_pane,
            bevorHaupttest_pane, alleProdukteNichtOK_pane, alleProdukteOK_pane, ende_pane;
    @FXML
    private Label testInOrdnung_text, testNichtInOrdnung_text, lblErrors, lblStatus1, lblStatus, lblStatusSchrank, lblStatusSchrank1, hinzufuegen_label, entfernen_label,
            time_label, slot_pruef_label, pruef_time_label, fehler_label, entfernen_label1, hinzufuegen_label2, init_timer_label, slot_pruef_label2, check_timer_label, nachtestinit_label,
            nachtestcheck_label, achtung_label, testDauer_label, verstrZeit_label, haupttest_label,testNichtInOrdnung_label;
    @FXML
    private TextField txtId, schrankid_txtfield1, schrankid_txtfield, benutzerid_txtfield, benutzerPassword_txtfield, benutzerName_txtfield,
            benutzerNachame_txtfield, benutzerid_txtfield1, schrank_benutzerid, benutzerRolle_txtfield, bauteil_textfield, auftrag_textfield,
            bauteil_textfield2, auftrag_textfield2;
    @FXML
    private PasswordField txtPassword;
    @FXML
    private ComboBox<String> slot_comboBox = new ComboBox<>();
    @FXML
    private ComboBox<String> slot_comboBox2 = new ComboBox<>();
    @FXML
    private ComboBox<String> schrankauswahl_comboBox = new ComboBox<>();
    @FXML
    private ProgressBar progressBar = new ProgressBar(0);
    //deneme amacli devre disi birakip sadece TableColumn versiyonunu test ettiydim bir sorun cikmadi
    @FXML
    private TableColumn<Gerate, Integer> bauteil_column, slot_column, bauteil_column1, slot_column1, slot_column2, bauteil_column2;
    @FXML
    private TableColumn<Gerate, String> auftrag_column, ergebnis_column, auftrag_column1, ergebnis_column1, ergebnis_column2, auftrag_column2;
    @FXML
    private TableView burnintest_table, burnintest_table1, burnintest_table2, burnintest_table3, burnintest_table4;

    //@FXML
    //private TableColumn slot_column, bauteil_column, auftrag_column, ergebnis_column;
    public sceneController() {
        con = ConnectionUtil.conDB();
    }

    @Override
    public void initialize(URL url, ResourceBundle rb) {
        loadBenutzerList();
        loadGerateList();
        burnintest_table1.setItems(tempGerateList);
        burnintest_table2.setItems(tempGerateList);
        fill_schrankAuswahlComboBox();
        schrankauswahl_comboBox.setEditable(false);
        schrankauswahl_comboBox.setValue("Schranken");
        schrankauswahl_comboBox.getItems().addAll(schranken);

        fill_slotsComboBox();
        slot_comboBox.setEditable(false);
        slot_comboBox.setValue("Slots");
        slot_comboBox.getItems().addAll(slots);
        slot_comboBox2.setEditable(false);
        slot_comboBox2.setValue("Slots");
        slot_comboBox2.getItems().addAll(slots);
    }
    /** düzeltilmesi gereken yerler
     * - haupttest işlemi / progress bar /pausieren / abbrechen
     * - abbrechen butonlarının tam işlevleri (yani geri gidildiginde mevcut sayfanın eski haline getirilmesi gibi...)
     * - benutzer ayarı --> admin/standard benutzer a gore menu ye iletilmesi
     */
    
    public void switchScreen(ActionEvent event, AnchorPane oldPaneId, AnchorPane newPaneId, String title) {
        oldPaneId.setVisible(false);
        newPaneId.setVisible(true);
        stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
        stage.setTitle(title);
    }
    private boolean processing = false;
    //initalisierung kısmındaki sayaç ve haupttest bölümündeki sayaç işlevlerini görüyor
    public void setTimer(int interval) {
        //Platform.setImplicitExit(false);
        Timer timer = new Timer();
        timer.scheduleAtFixedRate(new TimerTask() {
            int seconds = interval;
            int number = 0;
            int index = 0;
            int x = tempGerateList.size();

            @Override
            public void run() {
                processing = true;
                if (number <= interval && stage.getTitle().equals("Haupttest")) {
                    if (number % 10 == number) {
                        Platform.runLater(() -> verstrZeit_label.setText("00:00:0" + number));
                    } else {
                        Platform.runLater(() -> verstrZeit_label.setText("00:00:" + number));
                    }
                    Platform.runLater(() -> number++);
                } else if (seconds >= 0) {
                    if (seconds % 10 == seconds) {
                        if (stage.getTitle().equals("Nachtest")) {
                            Platform.runLater(() -> init_timer_label.setText("00:00:0" + seconds));
                        } else {
                            Platform.runLater(() -> time_label.setText("00:00:0" + seconds));
                        }
                    } else {
                        if (stage.getTitle().equals("Nachtest")) {
                            Platform.runLater(() -> init_timer_label.setText("00:00:" + seconds));
                        } else {
                            Platform.runLater(() -> time_label.setText("00:00:" + seconds));
                        }
                    }
                    //System.out.println(seconds);
                } else {
                    init_weiter_Button.setDisable(false);
                    if (stage.getTitle().equals("Nachtest")) {
                        nachtestinit_label.setDisable(true);
                        init_timer_label.setDisable(true);
                        //latch.countDown();
                        processing = false;
                    }
                    if (stage.getTitle().equals("Haupttest")) {
                        Platform.runLater(() -> haupttest_label.setText("Haupttest Ende..."));
                        geciciweiter_button.setDisable(false);
                        setHaupttestErgebnis();
                        
                    }
                    timer.cancel();
                }
                Platform.runLater(() -> seconds--);
            }
        }, 0, 1000);
    }
    //vortest ve nachtest bölümündeki sayaç işlevlerini görüyor ve tablo güncellemesini yapıyor
    public void setVortestTimer(int interval, int index) {
        try {
            sem.acquire();
        } catch (InterruptedException ex) {
            System.out.println("exception");
        }
        Timer timer = new Timer();
        timer.scheduleAtFixedRate(new TimerTask() {
            int seconds = interval;
            int x = tempGerateList.size();
            int y = index;
            //int k = tempGerateList.get(y).getSlot_id();

            @Override
            public void run() {
                while (processing && stage.getTitle().equals("Nachtest")) {
                    try {
                        Thread.sleep(1000);
                    } catch (InterruptedException ex1) {
                        Logger.getLogger(sceneController.class.getName()).log(Level.SEVERE, null, ex1);
                    }
                }
                nachtestcheck_label.setDisable(false);
                check_timer_label.setDisable(false);
                if (y != -1) {
                    int k = tempGerateList.get(y).getSlot_id();
                    if (stage.getTitle().equals("Nachtest")) {
                        Platform.runLater(() -> slot_pruef_label2.setText("Slot " + k + " wird geprueft."));
                    } else {
                        Platform.runLater(() -> slot_pruef_label.setText("Slot " + k + " wird geprueft."));
                    }
                    if (tempGerateList.get(y).getVortest_ergebnis().equals("Kein Ergebnis")) {
                        if (seconds > 0) {
                            if (seconds % 10 == seconds) {
                                if (stage.getTitle().equals("Nachtest") && init_timer_label.isDisabled()) {
                                    Platform.runLater(() -> check_timer_label.setText("00:00:0" + seconds));
                                } else {
                                    Platform.runLater(() -> pruef_time_label.setText("00:00:0" + seconds));
                                }
                            } else {
                                if (stage.getTitle().equals("Nachtest") && init_timer_label.isDisabled()) {
                                    Platform.runLater(() -> check_timer_label.setText("00:00:" + seconds));
                                } else {
                                    Platform.runLater(() -> pruef_time_label.setText("00:00:" + seconds));
                                }
                            }
                            Platform.runLater(() -> seconds--);
                        } else if (seconds == 0) {
                            Platform.runLater(() -> check_timer_label.setText("00:00:00"));
                            //System.out.println("slot numarası:" + k);
                            Random rand = new Random();
                            int f = rand.nextInt(2);
                            //System.out.println("rastgele sayı:" + k);
                            if (f == 0) {
                                tempGerateList.get(y).setVortest_ergebnis("Vortest nicht bestanden.");
                            } else {
                                tempGerateList.get(y).setVortest_ergebnis("Vortest bestanden.");
                            }
                            timer.cancel();
                            sem.release();
                            burnintest_table1.refresh();
                            y++;
                            processing = false;
                            if (y != x) {
                                setVortestTimer(interval, y);
                            } else {
                                Platform.runLater(() -> slot_pruef_label.setText("Vortest ist beendet."));
                                controlFehlerhafteProdukte();
                            }
                        }
                    } else {
                        timer.cancel();
                        sem.release();
                        y++;
                        processing = false;
                        if (y != x) {
                            System.out.println("index: " + y);
                            setVortestTimer(interval, y);
                        } else {
                            Platform.runLater(() -> slot_pruef_label.setText("Vortest ist beendet."));
                            controlFehlerhafteProdukte();
                        }
                    }
                } else {
                    timer.cancel();
                    sem.release();
                    y++;
                    processing = false;
                    setVortestTimer(interval, y);
                }
            }
        }, 0, 1000);

    }
    //vortest sonrası hatalı ürün kontrolü yapıyor
    //hatalı ürün mevcut ise nachteste gönderiyor
    public void controlFehlerhafteProdukte() {
        boolean check = true;
        for (int i = 0; i < tempGerateList.size(); i++) {
            if (tempGerateList.get(i).getVortest_ergebnis().equals("Vortest nicht bestanden.")) {
                sorunvar_isClicked();
                check = false;
                break;
            }
        }
        if (check == true) {
            sorunyok_isClicked();
        }
    }
    //haupttest içeriği belli olmadıgı için rastgele sayıya göre sonuc belirliyor   %75 başarı %25 başarısız
    public void setHaupttestErgebnis() {
        for (int i = 0; i < tempGerateList.size(); i++) {
            Random rand = new Random();
            int f = rand.nextInt(10);
            if (f <= 2) {
                tempGerateList.get(i).setHaupttest_ergebnis("Haupttest nicht bestanden.");
            } else {
                tempGerateList.get(i).setHaupttest_ergebnis("Haupttest bestanden.");
            }
            System.out.println("test sonucu girildi. ürün: " + tempGerateList.get(i).getSlot_id() + " sonuç: " + tempGerateList.get(i).getHaupttest_ergebnis());
        }
        burnintest_table2.setItems(tempGerateList);
        burnintest_table2.refresh();
    }
    //vortest sonrası hatalı ürünleri tablodan ve db den silme işlevini görüyor
    @FXML
    public void entfernenFehlerhafteProdukte() throws InterruptedException {
        int selectedIndex = burnintest_table1.getSelectionModel().getSelectedIndex();
        if (selectedIndex >= 0) {
            Gerate a = (Gerate) burnintest_table1.getSelectionModel().getSelectedItem();
            int slot_id = a.getSlot_bauteil_id()[0];
            int bauteil_id = a.getSlot_bauteil_id()[1];
            if (a.getVortest_ergebnis().equals("Vortest nicht bestanden.")) {
                tempGerateList.remove(a);
                gerateList.remove(a);
                entfernen_label1.setText("Slot " + slot_id + " ist aus der Tabelle entfernt.");
                //burnintest_table1.getItems().remove(selectedIndex);
                try {
                    String sql = "DELETE FROM gerate Where gerate_id=?";
                    preparedStatement = con.prepareStatement(sql);
                    preparedStatement.setInt(1, a.getBauteil());
                    preparedStatement.executeUpdate();
                    System.out.println("Gerat ist aus DB gelöscht");
                } catch (SQLException ex) {
                    System.err.println(ex.getMessage());
                }
            } else {
                fehler_label.setText("Das Produkt ist nicht fehlerhaft.");
            }
        } else {
            entfernen_label1.setText("Kein Slot ausgewählt.");
        }
        burnintest_table1.setItems(tempGerateList);

        burnintest_table1.getSelectionModel().clearSelection();
    }

    public void loadBenutzerList() {
        try {
            String st = "SELECT * FROM `benutzer`";
            preparedStatement = (PreparedStatement) con.prepareStatement(st);
            resultSet = preparedStatement.executeQuery();
            while (resultSet.next()) {
                benutzerList.add(new Benutzer(
                        resultSet.getInt("benutzer_id"),
                        resultSet.getString("password"),
                        resultSet.getString("name"),
                        resultSet.getString("nachname"),
                        resultSet.getString("rolle"),
                        resultSet.getBoolean("Online")));
            }
        } catch (SQLException ex) {
            System.out.println(ex.getMessage());
        }
    }

    public void loadGerateList() {
        try {
            String st = "SELECT * FROM gerate";
            preparedStatement = (PreparedStatement) con.prepareStatement(st);
            resultSet = preparedStatement.executeQuery();
            while (resultSet.next()) {
                gerateList.add(new Gerate(resultSet.getInt("gerate_id"), resultSet.getString("gerate_name"),
                        resultSet.getInt("start_temperatur"), resultSet.getInt("ziel_temperatur"),
                        resultSet.getInt("slot_id"), resultSet.getInt("benutzer_id"), resultSet.getString("auftrag"),
                        resultSet.getString("vortest_ergebnis"), resultSet.getString("haupttest_ergebnis")));
            }
        } catch (SQLException ex) {
            System.out.println(ex.getMessage());
        }
    }

    public boolean checkGerateSlot(String slot_id) {
        for (Gerate g : tempGerateList) {
            if (String.valueOf(g.getSlot_id()).equals(slot_id)) {
                return false;
            }
        }
        return true;
    }

    public boolean checkGerateId(int gerate_id) {
        for (Gerate g : gerateList) {
            if (g.getBauteil() == gerate_id) {
                return false;
            }
        }
        return true;
    }

    public void fill_schrankAuswahlComboBox() {

        try {

            String st = "SELECT klimaschrank_id FROM klimaschrank";
            preparedStatement = (PreparedStatement) con.prepareStatement(st);
            resultSet = preparedStatement.executeQuery();
            while (resultSet.next()) {
                schranken.add("Schrank" + resultSet.getString("klimaschrank_id"));
            }

        } catch (SQLException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }
    }

    public void fill_slotsComboBox() {
        try {
            String st = "SELECT slot_id FROM slot";
            preparedStatement = (PreparedStatement) con.prepareStatement(st);
            resultSet = preparedStatement.executeQuery();
            while (resultSet.next()) {
                slots.add(resultSet.getString("slot_id"));
            }

        } catch (SQLException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }
    }

    //we gonna use string to check for status
    private String logIn() {
        String status = "Success";
        String benutzer_id = txtId.getText();
        String password = txtPassword.getText();
        if (benutzer_id.isEmpty() || password.isEmpty()) {
            setLblError(Color.TOMATO, "Empty credentials");
            status = "Error";
        } else {
            //query
            String sql = "SELECT * FROM benutzer Where benutzer_id = ? and password = ?";
            try {
                preparedStatement = con.prepareStatement(sql);
                preparedStatement.setString(1, benutzer_id);
                preparedStatement.setString(2, password);
                resultSet = preparedStatement.executeQuery();
                if (!resultSet.next()) {
                    setLblError(Color.TOMATO, "Enter Correct Id/Password");
                    status = "Error";
                } else {
                    setLblError(Color.GREEN, "Login Successful..Redirecting..");
                }
            } catch (SQLException ex) {
                System.err.println(ex.getMessage());
                status = "Exception";
            }
        }
        benutzerDataSetOnline(benutzer_id);
        return status;
    }
    Benutzer aktuelleBenutzer = new Benutzer();

    public void benutzerDataSetOnline(String benutzer_id) {
        for (Benutzer b : benutzerList) {
            if (b.getId() == Integer.parseInt(benutzer_id)) {
                aktuelleBenutzer = b;
                b.setOnline(true);
                String sql = "UPDATE benutzer SET Online='" + 1 + "' WHERE benutzer_id='" + b.getId() + "' ";
                try {
                    preparedStatement = con.prepareStatement(sql);
                    preparedStatement.execute();
                } catch (SQLException ex) {
                    System.err.println(ex.getMessage());
                }
            }
        }
    }

    public void benutzerDataSetOffline() {
        for (Benutzer b : benutzerList) {
            if (b.isOnline()) {
                b.setOnline(false);
                String sql = "UPDATE benutzer SET Online='" + 0 + "' WHERE benutzer_id='" + b.getId() + "' ";
                try {
                    preparedStatement = con.prepareStatement(sql);
                    preparedStatement.execute();
                } catch (SQLException ex) {
                    System.err.println(ex.getMessage());
                }
            }
        }
    }

    private void setLblError(Color color, String text) {
        lblErrors.setTextFill(color);
        lblErrors.setText(text);
        System.out.println(text);
    }

    private void clear_Fields() {
        benutzerid_txtfield1.clear();
    }

    private String entfernenBenutzerData() {
        try {
            String st = "DELETE FROM benutzer where benutzer_id=?";
            preparedStatement = (PreparedStatement) con.prepareStatement(st);
            preparedStatement.setString(1, benutzerid_txtfield1.getText());
            preparedStatement.executeUpdate();
            lblStatus1.setTextFill(Color.GREEN);
            lblStatus1.setText("Benutzer erfolgreich entfernen");
            clear_Fields();
            return "Success";

        } catch (SQLException ex) {
            System.out.println(ex.getMessage());
            lblStatus1.setTextFill(Color.TOMATO);
            lblStatus1.setText(ex.getMessage());
            return "Exception";
        }

    }

    private void clearFields() {
        benutzerid_txtfield.clear();
        benutzerPassword_txtfield.clear();
        benutzerName_txtfield.clear();
        benutzerNachame_txtfield.clear();
        benutzerRolle_txtfield.clear();
    }

    private String hinzufuegenBenutzerData() {

        try {
            String st = "INSERT INTO benutzer (benutzer_id, password, name, nachname, rolle) VALUES (?,?,?,?,?)";
            preparedStatement = (PreparedStatement) con.prepareStatement(st);
            preparedStatement.setString(1, benutzerid_txtfield.getText());
            preparedStatement.setString(2, benutzerPassword_txtfield.getText());
            preparedStatement.setString(3, benutzerName_txtfield.getText());
            preparedStatement.setString(4, benutzerNachame_txtfield.getText());
            preparedStatement.setString(5, benutzerRolle_txtfield.getText());
            preparedStatement.executeUpdate();
            lblStatus.setTextFill(Color.GREEN);
            lblStatus.setText("Benutzer erfolgreich hinzugefügt");
            clearFields();
            return "Success";

        } catch (SQLException ex) {
            System.out.println(ex.getMessage());
            lblStatus.setTextFill(Color.TOMATO);
            lblStatus.setText(ex.getMessage());
            return "Exception";
        }
    }

    private void clearSchrank_Fields() {
        schrankid_txtfield.clear();
    }

    private String entfernenSchrankData() {
        try {
            String st = "DELETE FROM klimaschrank where klimaschrank_id=?";
            preparedStatement = (PreparedStatement) con.prepareStatement(st);
            preparedStatement.setString(1, schrankid_txtfield.getText());
            preparedStatement.executeUpdate();
            lblStatusSchrank.setTextFill(Color.GREEN);
            lblStatusSchrank.setText("Schrank erfolgreich entfernen");
            clearSchrank_Fields();
            return "Success";

        } catch (SQLException ex) {
            System.out.println(ex.getMessage());
            lblStatusSchrank.setTextFill(Color.TOMATO);
            lblStatusSchrank.setText(ex.getMessage());
            return "Exception";
        }

    }

    private String hinzufuegenSchrankData() {

        try {
            String st = "INSERT INTO klimaschrank (klimaschrank_id,benutzer_id) VALUES (?,?)";
            preparedStatement = (PreparedStatement) con.prepareStatement(st);
            preparedStatement.setString(1, schrankid_txtfield1.getText());
            preparedStatement.setString(2, schrank_benutzerid.getText());
            preparedStatement.executeUpdate();
            lblStatusSchrank1.setTextFill(Color.GREEN);
            lblStatusSchrank1.setText("Schrank erfolgreich hinzugefügt");
            clearSchrank1_Fields();
            return "Success";

        } catch (SQLException ex) {
            System.out.println(ex.getMessage());
            lblStatusSchrank1.setTextFill(Color.TOMATO);
            lblStatusSchrank1.setText(ex.getMessage());
            return "Exception";
        }
    }

    private void clearSchrank1_Fields() {
        schrankid_txtfield1.clear();
        schrank_benutzerid.clear();
    }

    private void hinzufuegenGerateData(Gerate g) {

        Benutzer benutzer = new Benutzer();
        for (Benutzer b : benutzerList) {
            if (b.isOnline()) {
                benutzer = b;
            }
        }

        try {
            String st = "INSERT INTO gerate (gerate_id, gerate_name, start_temperatur, ziel_temperatur, auftrag, slot_id, benutzer_id, vortest_ergebnis, haupttest_ergebnis) VALUES (?,?,?,?,?,?,?,?,?)";
            preparedStatement = (PreparedStatement) con.prepareStatement(st);
            preparedStatement.setInt(1, g.getBauteil());
            preparedStatement.setString(2, g.getName());
            preparedStatement.setInt(3, g.getStart_temperatur());
            preparedStatement.setInt(4, g.getZiel_temperatur());
            preparedStatement.setString(5, g.getAuftrag());
            preparedStatement.setInt(6, g.getSlot_id());
            preparedStatement.setInt(7, benutzer.getId());
            preparedStatement.setString(8, g.getVortest_ergebnis());
            preparedStatement.setString(9, g.getHaupttest_ergebnis());
            //TODO databasede benutzer icin online attribute kaydedildiginde ustteki satir yerine alttaki calisacak
            //preparedStatement.setInt(7, benutzer.getId());
            preparedStatement.executeUpdate();
            if (stage.getTitle().equals("Testprodukt Check-In")) {
                burnintest_table.getItems().add(g);
                burnintest_table.getSortOrder().add(slot_column);
                burnintest_table.sort();
            }
            gerateList.add(g);
            tempGerateList.add(g);
            if (stage.getTitle().equals("Nachtest")) {
                burnintest_table1.getSortOrder().add(slot_column);
                burnintest_table1.sort();
                burnintest_table1.setItems(tempGerateList);
                burnintest_table1.refresh();
                Collections.sort(tempGerateList, new sortGerate());
            }

        } catch (SQLException ex) {
            System.out.println(ex.getMessage());
        }
    }

    //urun eklerken bauteil_id primary key olarak dusunuldu yani
    //ayni urunu 2. kez DB ye yuklemesine izin vermeyecek ve
    //ayni slota 2. bir urun yerlestirilemeyecek 
    //slotlar farkli sirada doldurulabiliyor ama tablodan kucuk<buyuk veya
    //tersine siralama ozelligine sahip
    public void connectColumnToGerate() {
        slot_column.setCellValueFactory(new PropertyValueFactory<>("slot_id"));
        bauteil_column.setCellValueFactory(new PropertyValueFactory<>("bauteil"));
        auftrag_column.setCellValueFactory(new PropertyValueFactory<>("auftrag"));
        ergebnis_column.setCellValueFactory(new PropertyValueFactory<>("vortest_ergebnis"));
        slot_column1.setCellValueFactory(new PropertyValueFactory<>("slot_id"));
        bauteil_column1.setCellValueFactory(new PropertyValueFactory<>("bauteil"));
        auftrag_column1.setCellValueFactory(new PropertyValueFactory<>("auftrag"));
        ergebnis_column1.setCellValueFactory(new PropertyValueFactory<>("vortest_ergebnis"));
        slot_column2.setCellValueFactory(new PropertyValueFactory<>("slot_id"));
        bauteil_column2.setCellValueFactory(new PropertyValueFactory<>("bauteil"));
        auftrag_column2.setCellValueFactory(new PropertyValueFactory<>("auftrag"));
        ergebnis_column2.setCellValueFactory(new PropertyValueFactory<>("haupttest_ergebnis"));
        slot_column1.setSortable(false);
        bauteil_column1.setSortable(false);
        auftrag_column1.setSortable(false);
        ergebnis_column1.setSortable(false);
    }

    @FXML
    void hinzufuegen_buttonClicked(ActionEvent event) {
        connectColumnToGerate();
        ComboBox<String> x = new ComboBox<>();
        TextField bauteil = new TextField();
        TextField auftrag = new TextField();
        Label label = new Label();
        if (stage.getTitle().equals("Nachtest")) {
            x = slot_comboBox2;
            bauteil = bauteil_textfield2;
            auftrag = auftrag_textfield2;
            label = hinzufuegen_label2;
        } else {
            x = slot_comboBox;
            bauteil = bauteil_textfield;
            auftrag = auftrag_textfield;
            label = hinzufuegen_label;
        }
        if (x.getSelectionModel().getSelectedItem().equals("Slots") || bauteil.getText().isEmpty()
                || auftrag.getText().isEmpty()) {
            label.setTextFill(Color.TOMATO);
            label.setText("Geben Sie alle Details ein");
        } else if (!checkGerateId(Integer.parseInt(bauteil.getText()))) {
            label.setTextFill(Color.TOMATO);
            label.setText("Geraet-ID existiert. Kontrollieren Sie bitte das Geraet-Id.");
        } else if (!checkGerateSlot(x.getSelectionModel().getSelectedItem())) {
            label.setTextFill(Color.TOMATO);
            label.setText("Dieses Slot ist besetzt waehlen Sie bitte ein anderes Slot.");
        } else {
            label.setText("");
            Gerate gerate = new Gerate();
            gerate.setSlot_id(Integer.parseInt(x.getSelectionModel().getSelectedItem()));
            gerate.setBauteil(Integer.parseInt(bauteil.getText()));
            gerate.setAuftrag(auftrag.getText());
            label.setTextFill(Color.GREEN);
            label.setText("Geraet erfolgreich hinzugefügt");
            bauteil.clear();
            auftrag.clear();
            hinzufuegenGerateData(gerate);

        }
    }

    //urun kaldirma seklini degistirmek zorunda kaldim comboboxtan tablo satirini secmeyi yapamadim
    //onun yerine tablodan urun satirina tiklayip sil butonuna basiyoruz ve urun tablodan ve DB den siliniyor
    @FXML
    void entfernen_gerateData(ActionEvent event) throws InterruptedException {
        int selectedIndex = burnintest_table.getSelectionModel().getSelectedIndex();
        if (selectedIndex >= 0) {
            Gerate a = (Gerate) burnintest_table.getSelectionModel().getSelectedItem();
            int slot_id = a.getSlot_bauteil_id()[0];
            int bauteil_id = a.getSlot_bauteil_id()[1];
            tempGerateList.remove(a);
            gerateList.remove(a);
            entfernen_label.setText("Slot " + slot_id + " ist aus der Tabelle entfernt.");
            burnintest_table.getItems().remove(selectedIndex);
            try {
                String sql = "DELETE FROM gerate Where gerate_id=?";
                preparedStatement = con.prepareStatement(sql);
                preparedStatement.setInt(1, a.getBauteil());
                preparedStatement.executeUpdate();
                System.out.println("Gerat ist aus DB gelöscht");
            } catch (SQLException ex) {
                System.err.println(ex.getMessage());
            }
        } else {
            entfernen_label.setText("Kein Slot ausgewählt.");
        }
        burnintest_table.getSelectionModel().clearSelection();
    }

    @FXML
    void benutzerhinzufuegen_buttonClicked(ActionEvent event) {
        if (benutzerid_txtfield.getText().isEmpty() || benutzerPassword_txtfield.getText().isEmpty() || benutzerName_txtfield.getText().isEmpty() || benutzerNachame_txtfield.getText().isEmpty()) {
            lblStatus.setTextFill(Color.TOMATO);
            lblStatus.setText("Geben Sie alle Details ein");
        } else {
            hinzufuegenBenutzerData();
        }
    }

    @FXML
    void benutzerentfernen_buttonClicked(ActionEvent event) {
        if (benutzerid_txtfield1.getText().isEmpty()) {
            lblStatus1.setTextFill(Color.TOMATO);
            lblStatus1.setText("Geben Sie alle Details ein");
        } else {
            entfernenBenutzerData();
        }
    }

    @FXML
    void benutzerstellung_is_Clicked(ActionEvent event) {
        switchScreen(event, settingsPane, benutzerSettingsPane, "Benutzer-Einstellungen");
    }

    @FXML
    void schrankstellung_is_Clicked(ActionEvent event) {
        switchScreen(event, settingsPane, schrankSettingsPane, "Schrank-Einstellungen");
    }

    @FXML
    void schrankentfernen_buttonClicked(ActionEvent event) {
        if (schrankid_txtfield.getText().isEmpty()) {
            lblStatusSchrank.setTextFill(Color.TOMATO);
            lblStatusSchrank.setText("Geben Sie alle Details ein");
        } else {
            entfernenSchrankData();
        }
    }

    @FXML
    void schrankhinzufuegen_buttonClicked(ActionEvent event) {
        if (schrankid_txtfield1.getText().isEmpty() || schrank_benutzerid.getText().isEmpty()) {
            lblStatusSchrank1.setTextFill(Color.TOMATO);
            lblStatusSchrank1.setText("Geben Sie alle Details ein");
        } else {
            hinzufuegenSchrankData();
        }
    }

    @FXML
    void menuzuruckgehen_isClicked(ActionEvent event) {
        switchScreen(event, benutzerSettingsPane, menuAdminPane, "Einstellungen");
        switchScreen(event, schrankSettingsPane, menuAdminPane, "Einstellungen");
        lblStatus.setText("");
        lblStatus1.setText("");
        lblStatusSchrank.setText("");
        lblStatusSchrank1.setText("");
    }

    //Einstellungen ausgewählt
    @FXML
    void settings_button_isClicked(ActionEvent event) {
        switchScreen(event, menuAdminPane, settingsPane, "Einstellungen");
    }

    @FXML
    void login_button_isClicked(ActionEvent event) {
        if (logIn().equals("Success")) {
            switchScreen(event, loginPane, schrankPane, "Schrankauswahl");
        }
    }

    //Schrankauswahl
    @FXML
    void confirm_button_isClicked(ActionEvent event) {
        //if
        switchScreen(event, schrankPane, menuAdminPane, "Menu");
        //else
        //switchScreen(event, schrankPane, menuBenutzerPane, "Menu");
    }

    //Testbetrieb ausgewählt
    @FXML
    void testbetrieb_button_isClicked(ActionEvent event) {
        switchScreen(event, menuAdminPane, initialisierungStartPane, "Initialisierung Starten");
        init_weiter_Button.setDisable(true);
    }

    //Handbetrieb ausgewählt
    @FXML
    void handbetrieb_button_isClicked(ActionEvent event) {

    }

    //Programm beenden
    @FXML
    void exit_button_isClicked(ActionEvent event) {
        System.exit(0);
    }

    //Abbrechen führt immer zurück zum Hauptmenü
    @FXML
    void abbrechen_button_isClicked(ActionEvent event) {
        //geri butonunu iptal ettim nasıl olacağına toplu karar veririz
        //düzenleme gerekli
    }

    //Initialisierung starten
    @FXML
    void initialisierungStart_button_isClicked(ActionEvent event) {
        switchScreen(event, initialisierungStartPane, initialisierungPane, "Initialisierung");
        setTimer(15);
    }

    //Weiter button zum Testprodukt Check-In Starten
    @FXML
    void weiterZumTestProduktCheckIn_button_isClicked(ActionEvent event) {
        switchScreen(event, initialisierungPane, weiterZumTestProduktCheckInPane, "Testprodukt Check-In Starten");
    }

    //Testprodukt Check-In Starten
    @FXML
    void testProduktCheckStart_button_isClicked(ActionEvent event) {
        switchScreen(event, weiterZumTestProduktCheckInPane, testProduktCheckInPane, "Testprodukt Check-In");
    }

    @FXML
    public void fertig_button_isClicked(ActionEvent event) {
        if (tempGerateList.isEmpty()) {
            achtung_label.setText("Kein Produkt vorhanden!!!");
        } else {
            produkt_pane1.setVisible(false);
            erfolgreich_pane1.setVisible(true);
            fertig_pane1.setVisible(false);
            funktest_pane1.setVisible(true);
            hinzufuegen_label.setText("");
            achtung_label.setText("");
            entfernen_label.setText("");
            Collections.sort(tempGerateList, new sortGerate());
        }
    }

    @FXML
    public void funktest_button_isClicked(ActionEvent event) {
        switchScreen(event, testProduktCheckInPane, vortestPane, "Vortest");
        produkt_pane1.setVisible(true);
        erfolgreich_pane1.setVisible(false);
        fertig_pane1.setVisible(true);
        funktest_pane1.setVisible(false);
        setVortestTimer(5, -1);
    }

    //TODO "sorunvar" "sorunyok" butonlari silinecek testin sonucuna gore ekranlar otomatik acilacak
    @FXML
    public void sorunvar_isClicked() {
        pruef_pane.setVisible(false);
        fehler_pane.setVisible(true);
        abbrechen_button.setVisible(true);
        sorunvar.setVisible(false);
        sorunyok.setVisible(false);
        nachtest_pane.setVisible(false);
    }

    @FXML
    public void sorunyok_isClicked() {
        pruef_pane.setVisible(false);
        bevorHaupttest_pane.setVisible(true);
        abbrechen_button.setVisible(true);
        sorunvar.setVisible(false);
        sorunyok.setVisible(false);

        nachtest_pane.setVisible(false);
    }

    @FXML
    public void kontroll_button_isClicked(ActionEvent event) {
        //TODO eger hatali urunler uzaklastirilmadiysa burda kalacak
        boolean check = true;
        for (int i = 0; i < tempGerateList.size(); i++) {
            if (tempGerateList.get(i).getVortest_ergebnis().equals("Vortest nicht bestanden.")) {
                fehler_label.setText("Es existieren noch fehlerhafte Produkte!!!");
                check = false;
                break;
            }
        }
        if (check == true) {
            fehler_pane.setVisible(false);
            bevorNachtest_pane.setVisible(true);
            stage.setTitle("Nachtest");
            fehler_label.setText("Fehlerhafte Produkte erkannt!");
            entfernen_label1.setText("");
            hinzufuegen_label2.setText("");
        }
        nachtestinit_label.setDisable(false);
        init_timer_label.setDisable(false);
        nachtestcheck_label.setDisable(true);
        check_timer_label.setDisable(true);
        slot_pruef_label.setText("Slot x wird geprueft.");
        slot_pruef_label2.setText("");
    }

    @FXML
    public void nachtest_button_isClicked(ActionEvent event) {
        boolean check = true;
        for (int i = 0; i < tempGerateList.size(); i++) {
            if (tempGerateList.get(i).getVortest_ergebnis().equals("Kein Ergebnis")) {
                check = false;
                break;
            }
        }
        if (tempGerateList.isEmpty()) {
            hinzufuegen_label2.setText("Kein Produkt vorhanden!!!");
        } else {
            bevorNachtest_pane.setVisible(false);
            if (!check) {
                nachtest_pane.setVisible(true);
                
                abbrechen_button.setVisible(false);
                setTimer(12);
                setVortestTimer(5, -1);
            } else {
                //nachtest'te yeni ürün eklenmediyse haupttest sayfasına yönlendirir
                bevorHaupttest_pane.setVisible(true);
            }
            hinzufuegen_label2.setText("");
        }

        //TODO "sorunvar" "sorunyok" butonlari silinecek testin sonucuna gore ekranlar otomatik acilacak
    }

    @FXML
    public void haupttestStartButton_isClicked(ActionEvent event) {
        switchScreen(event, vortestPane, haupttestPane, "Haupttest");
        bevorHaupttest_pane.setVisible(false);
        bevorNachtest_pane.setVisible(false);
        fehler_pane.setVisible(false);
        pruef_pane.setVisible(true);
        geciciweiter_button.setDisable(true);
        if (aktuelleBenutzer.getRolle().equals("standard")) {
            pauseTest_button.setDisable(true);
            abbrechenTest_button.setDisable(true);
        }
        setTimer(15);
    }

    @FXML
    public void geciciWeiterButton_isClicked(ActionEvent event) {
        switchScreen(event, haupttestPane, funktionCheckPane, "Funktions Check Scene");
        geciciweiter_button.setDisable(true);
        boolean check = true;
        for (int i = 0; i < tempGerateList.size(); i++) {
            if (tempGerateList.get(i).getHaupttest_ergebnis().equals("Haupttest nicht bestanden.")) {
                check = false;
                alleProdukteNichtOK_pane.setVisible(true);
                break;
            }
        }
        if (check == true) {
            alleProdukteOK_pane.setVisible(true);
        }
    }
    //haupttest sonunda başarılı ve başarısız ürünler için ayrı kayıt tutup databese de tutabiliriz ?
    @FXML
    public void nichtinOrdnung_button_isClicked(ActionEvent event) {
        for (int i = 0; i < tempGerateList.size(); i++) {
            if (tempGerateList.get(i).getHaupttest_ergebnis().equals("Haupttest nicht bestanden.")) {
                fehlerhafteGerateList.add(tempGerateList.get(i));
            }
        }
        testNichtInOrdnung_button.setVisible(false);
        testNichtInOrdnung_label.setText("Nicht in Ordnung Produkte gespeichert!");
        System.out.println("fehlerhafte produkte gespeichert");
    }

    @FXML
    public void inOrdnung_button_isClicked(ActionEvent event) {
        for (int i = 0; i < tempGerateList.size(); i++) {
            if (tempGerateList.get(i).getHaupttest_ergebnis().equals("Haupttest bestanden.")) {
                korrektGerateList.add(tempGerateList.get(i));
            }
        }
        testNichtInOrdnung_label.setText("Manche Produkte haben den Haupttest nicht bestanden!");
        alleProdukteNichtOK_pane.setVisible(false);
        testNichtInOrdnung_button.setVisible(true);
        ende_pane.setVisible(true);
        System.out.println("korrekte produkte gespeichert");
    }

    @FXML
    public void abbrechenTest_isClicked(ActionEvent event) {

    }

    @FXML
    public void pauseTest_isClicked(ActionEvent event) {

    }

    @FXML
    void testInOrdnung_isClicked(ActionEvent event) {
        ende_pane.setVisible(true);
    }

    @FXML
    void testNichtInOrdnung_isClicked(ActionEvent event) {
        switchScreen(event, funktionCheckPane, funktionCheckPane2, "Funktions Ordnung Scene");
    }

    @FXML
    void testInOrdnung2_isClicked(ActionEvent event) {
        switchScreen(event, funktionCheckPane2, endePane, "Funktions Ordnung Scene");
    }

    @FXML
    void endeClicked(ActionEvent event) {
        //if
        switchScreen(event, funktionCheckPane, menuAdminPane, "Returning Main Menu");
        //else
        //switchScreen(event,funktionCheckEndePane,menuBenutzerPane, "Returning Main Menu");
        slot_comboBox.setValue("Slots");
        slot_comboBox2.setValue("Slots");
        ende_pane.setVisible(false);
        burnintest_table.getItems().clear();
        burnintest_table1.getItems().clear();
        burnintest_table2.getItems().clear();
        tempGerateList.clear();
        fehlerhafteGerateList.clear();
        korrektGerateList.clear();
    }

}
